<html><head><title>Register Form</title></head>
<script language="javascript" src="jquery-1.7.1.min.js"></script>

<body>
<table align="right"><tr><td><a href="home.php">Home</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="register.php">Register</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="usermain.php">User Login</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="adminmain.php">Admin</a></td></tr></table>

<br><br><br><br>

<center>
<h1>Registration Form</h1>
<table style="height: 400px; width: 400px;"><tr><td>NAME</td><td><input type="text" id="t1"></td></tr>
<tr><td>DOB</td><td><select id=s1><option>Date</option>
<?php
 for ($i=1;$i<=31;$i++)
 {
    echo "<option value=$i>$i</option>";
 }   
?>
</select>   <select id="s2"><option>Month</option>
<option value="jan">Jan</option>
<option value="feb">Feb</option>
<option value="mar">March</option>
<option value="april">April</option>
<option value="may">May</option>
<option value="june">June</option>
<option value="july">July</option>
<option value="aug">Aug</option>
<option value="sep">Sep</option>
<option value="oct">Oct</option>
<option value="nov">Nov</option>
<option value="Dec">dec</option>
</select>   <select id=s3><option>Year</option>
<?php
for ($i=1990;$i<=2017;$i++)
{
    echo "<option value=$i>$i</option>";
}
?>
</select></td></tr>
<tr><td>GENDER</td><td><input type="radio" id="r1" name="r1"  value="male">Male  <input type="radio" id="r2" name="r1"  value="female">Female</td></tr>
<tr><td>QUALIFICATION</td><td><input type="text" id="t2" name="t2"></td></tr>
<tr><td>
E_MAIL</td><td><input type="text" id="t3" ></td></tr>
<tr><td>MOBILE NO</td><td><input type="text" id="t4" name="t4"></td></tr>
<tr><td>USER NAME</td><td><input type="text" id="t5"></td></tr>
<tr><td>PASSWORD</td><td><input type="text" id="t6"></td></tr>
</table><br>
<input type="image" src="submit.png" onclick="insert()">
</center>
</body>
<script type="text/javascript">
function insert()
{
 var p=$("#t1").val();
 var p1=$("#s1").val();
 var p2=$("#s2").val();
 var p3=$("#s3").val();
 

 //alert(p4);
var p4= $('input[name="r1"]:checked').val();
var p5=$("#t2").val();
var p6=$("#t3").val();
var p7=$("#t4").val();
var p8=$("#t5").val();
var p9=$("#t6").val();
var send=p+"#"+p1+"#"+p2+"#"+p3+"#"+p4+"#"+p5+"#"+p6+"#"+p7+"#"+p8+"#"+p9;
$.post("insert.php",{sendTovalue :""+send+""},
function(data)
{
 if(data.indexOf("insert") > -1)
      {
         alert ("Successfully Inserted");
                              
      }
 else
    {                         
        alert("Record Not Inserted");
    }   
});

}

</script>
</html>
