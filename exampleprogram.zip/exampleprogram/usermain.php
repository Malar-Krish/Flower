<html><head><title>Register Form</title></head>
<script language="javascript" src="jquery-1.7.1.min.js"></script>

<body onload="file()">
<table align="right"><tr><td><a href="home.php">Home</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="register.php">Register</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="userlogin.php">User Login</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="adminmain.php">Admin</a></td></tr></table>

<br><br><br><br>

<center>
<h1><font face="Times new roman">User Login</h1></font> <br><br>
 <p id="DeptDiv" name="DeptDiv"></p>
</center>
</body>
<script type="text/javascript">
 function  file()
            {
              
                 $.post("logform.php",
    function(data)
    {
           $('#DeptDiv').show();
                $('#DeptDiv').html(data);   
    }) ;  
            }
             function log()
            {
                //alert("hello");
                var p=$("#username").val();
                var p1=$("#password").val();
               
                var SendValue=p+"#"+p1;
                $.post("logincheck.php",{sendTovalue:""+SendValue+""},
                function(data)
                {       
                    data = $.trim(data);
                    //alert(data);
        if (data.indexOf("available") > -1)
        {
                         $.post("wel.php",
    function(data)
    {
           $('#DeptDiv').show();
                $('#DeptDiv').html(data);   
    }) ;  
                     }
                     else if(data.indexOf("invalid")> -1)
                     {
                         alert("Invalid Login");
                         $('#username').focus();
                     }
                
                });
            }
            </script>
</html>

