<?php
ob_start();
session_start();
ob_get_flush();
include_once "conn.inc";


   $Val = $_POST['sendTovalue'];
   $array = explode("#",$Val);
   $name = $array[0] ;
   $pwd = $array[1];
 
  
    $sql ="select * from admin where username='$name' and password='$pwd'  " ;
    $res=record_count($sql);
    
             if ($res>0) 
       {
           $_SESSION['name']=$name;
         
          echo "available";
       }
       else
        {
             echo "invalid";
             
       }
           

?>


