<?php
  ob_start();
session_start();
ob_get_flush();
include_once "conn.inc";



  $Val = $_POST['sendTovalue'];
   $array = explode("#",$Val);
  $p = $array[0] ;
   $p1 = $array[1];
      $p2 = $array[2];
         $p3 = $array[3];
            $p4 = $array[4];
               $p5 = $array[5];
                  $p6 = $array[6];
                     $p7 = $array[7];
                      $p8 = $array[8];
                      $p9=$array[9];
                             
$p10=$p1."-".$p2."-".$p3;                                     
                                   
                                     $sql="insert into register values('$p','$p10','$p4','$p5','$p6','$p7','$p8','$p9')";
                                     $res=insert_select_record($sql); 
                                      if($res>0)
                                     {
                                         echo "insert";
                                         
                                     }
                                     else
                                     {
                                         echo "error";
                                     }
                                        
                                 
?>
