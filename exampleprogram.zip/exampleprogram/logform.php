


<table style="height: 100px; width: 400px;"><tr><td>USER NAME</td><td><input type="text" id="username"></td></tr>
<tr><td>PASSWORD</td><td><input type="password" id="password"></td></tr>
</table><br><br>

<input type="image" src="submit.png" onclick="log()">