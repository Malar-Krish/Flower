<?php
ob_start();
session_start();
ob_get_flush();
include_once "conn.inc";


   $p=$_SESSION['name'];
 
  
    $sql="select * from register where username='$p'";
    $res=multiple_record_return($sql);
    if ($res>0)
    {
        echo "<font color='black'>";
        echo "<table style='height:100px; width:1000px; border-collapse:collapse;' border='1' font='Times New Roman' >";
        echo "<tr><th>First Name</th> <th>Date of Birth </th> <th>Gender </th> <th>Qualification </th><th>Email</th><th>Mobile No</th>    </tr></tr>";
        foreach ($res as $field)
        {
           
            
            echo "<tr><td>$field[fname]</td><td>$field[dob]</td><td>$field[gender]</td><td>$field[qualification]</td><td>$field[email]</td><td>$field[mobileno]</td></tr>";
        }
            echo "</table>";
            echo "</font><br>";
          // echo "<a href='adindex.php'><img src='images/cate3.png' alt=''></a>"  ;
    }
    else
    {
        echo "error";
    }
?>
           



