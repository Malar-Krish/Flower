<html><head><title>Home Page</title></head>
<body>
<table align="right"><tr><td><a href="home.php">Home</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="register.php">Register</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="usermain.php">User Login</a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href="adminmain.php">Admin</a></td></tr></table>
<br><br><br><br><br>
<center><img src="img2.jpg" alt=""></center>

</body></html>
